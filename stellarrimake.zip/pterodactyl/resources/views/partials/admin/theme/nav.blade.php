@section('theme::nav')
    <div class="row">
        <div class="col-xs-12">
            <div class="nav-tabs-custom nav-tabs-floating">
                <ul class="nav nav-tabs">
                    <li @if($activeTab === 'theme')class="active"@endif><a href="{{ route('admin.theme') }}">Pengaturan Theme</a></li>
                    <li @if($activeTab === 'color')class="active"@endif><a href="{{ route('admin.theme.color') }}">Pengaturan Warna</a></li>
                    <li @if($activeTab === 'meta')class="active"@endif><a href="{{ route('admin.theme.meta') }}">Pengaturan meta</a></li>
                    <li @if($activeTab === 'button')class="active"@endif><a href="{{ route('admin.theme.button') }}">Pengaturan Buttons & Input</a></li>
                    <li @if($activeTab === 'element')class="active"@endif><a href="{{ route('admin.theme.element') }}">Pengaturan Elements</a></li>
                    <li @if($activeTab === 'alert')class="active"@endif><a href="{{ route('admin.theme.alert') }}">Pengaturan Alert</a></li>
                    <li @if($activeTab === 'social')class="active"@endif><a href="{{ route('admin.theme.social') }}">Pengaturan Social</a></li>
                </ul>
            </div>
        </div>
    </div>
@endsection
